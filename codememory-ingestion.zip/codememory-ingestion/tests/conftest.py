import re
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT))

SAMPLE_DIR = PROJECT / "data" / "sample_repositories"
TEST_DATA = PROJECT / "data" / "test_data"


class FakeHindsight:
    """TEST-ONLY stand-in with the same interface as HindsightMemory, so the pipeline can be
    tested without a Hindsight server. The app itself never uses it."""

    name = "fake"

    def __init__(self):
        self.docs = {}

    def ensure_bank(self, bank_id, name):
        pass

    def retain(self, bank_id, text, *, context, timestamp, document_id):
        self.docs[(bank_id, document_id)] = {"text": text, "context": context, "timestamp": timestamp}

    def recall(self, bank_id, query, limit=8):
        q = set(re.findall(r"[a-z0-9]+", query.lower().replace("_", " ")))
        scored = []
        for (b, _), rec in self.docs.items():
            if b == bank_id:
                overlap = q & set(re.findall(r"[a-z0-9]+", rec["text"].lower().replace("_", " ")))
                if overlap:
                    scored.append((len(overlap), rec["text"]))
        scored.sort(reverse=True)
        return [t for _, t in scored[:limit]]
