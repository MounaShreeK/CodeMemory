import pytest

from codememory_ingestion.code_analyzer import (_load_parser, detect_language, extract_symbols,
                               map_changes_to_symbols)
from codememory_ingestion.diff_parser import parse_patch

PY = '''import os


@decorator
def top(a):
    return a


class Service:
    def run(self):
        def inner():
            return 1
        return inner()

    async def stop(self):
        pass
'''

JS = '''export function alpha() {
  return 1;
}

const beta = (x) => {
  return x * 2;
};

class Gamma {
  delta() {
    return 3;
  }
}
'''


def names(symbols):
    return {s.qualified_name: (s.kind, s.start_line, s.end_line) for s in symbols}


def test_language_detection():
    assert detect_language("a/b.py") == "python"
    assert detect_language("x.tsx") == "tsx"
    assert detect_language("x.md") is None


def test_python_symbols_ast_fallback():
    symbols, analyzer = extract_symbols("m.py", PY, prefer_tree_sitter=False)
    assert analyzer == "python-ast"
    got = names(symbols)
    assert got["top"] == ("function", 4, 6)  # span includes the decorator
    assert got["Service"][0] == "class"
    assert got["Service.run"][0] == "method"
    assert got["Service.run.inner"][0] == "function"
    assert got["Service.stop"][0] == "method"


def test_syntax_error_returns_no_symbols():
    symbols, _ = extract_symbols("bad.py", "def (:\n", prefer_tree_sitter=False)
    assert symbols == []


def test_unsupported_language():
    assert extract_symbols("README.md", "# hi") == ([], "unsupported")


def test_innermost_symbol_wins_and_module_level_is_reported():
    symbols, _ = extract_symbols("m.py", PY, prefer_tree_sitter=False)
    inner_line = 12  # "return 1" inside inner()
    patch = f"@@ -{inner_line} +{inner_line} @@\n-            return 0\n+            return 1\n@@ -1 +1 @@\n-import sys\n+import os"
    changes = {c.symbol.qualified_name: c for c in map_changes_to_symbols(symbols, parse_patch(patch), 20)}
    assert "Service.run.inner" in changes
    assert "<module>" in changes
    assert changes["Service.run.inner"].added == 1 and changes["Service.run.inner"].removed == 1


def test_removed_line_is_attributed_to_the_function_it_left():
    # a condition deleted from the middle of Service.run
    patch = "@@ -10,3 +10,2 @@\n     def run(self):\n-        old = 1\n         return 1"
    symbols, _ = extract_symbols("m.py", PY, prefer_tree_sitter=False)
    changes = map_changes_to_symbols(symbols, parse_patch(patch), 20)
    assert [c.symbol.qualified_name for c in changes] == ["Service.run"]


def test_replaced_signature_line_stays_with_its_method():
    from conftest import TEST_DATA

    content = (TEST_DATA / "payment_fix_after.py").read_text(encoding="utf-8")
    patch = (TEST_DATA / "payment_fix.patch").read_text(encoding="utf-8")
    symbols, _ = extract_symbols("payments/service.py", content, prefer_tree_sitter=False)
    changes = {c.symbol.qualified_name: c for c in map_changes_to_symbols(symbols, parse_patch(patch), 30)}
    assert set(changes) == {"PaymentService.__init__", "PaymentService.process_payment"}
    assert changes["PaymentService.process_payment"].removed == 2  # old signature + old return


@pytest.mark.skipif(_load_parser("python") is None, reason="tree-sitter not installed")
def test_tree_sitter_matches_ast_for_python():
    ts, analyzer = extract_symbols("m.py", PY)
    assert analyzer == "tree-sitter"
    ast_symbols, _ = extract_symbols("m.py", PY, prefer_tree_sitter=False)
    assert names(ts) == names(ast_symbols)


@pytest.mark.skipif(_load_parser("javascript") is None, reason="tree-sitter-javascript not installed")
def test_tree_sitter_javascript():
    symbols, analyzer = extract_symbols("a.js", JS)
    assert analyzer == "tree-sitter"
    got = names(symbols)
    assert got["alpha"][0] == "function"
    assert got["beta"][0] == "function"
    assert got["Gamma"][0] == "class"
    assert got["Gamma.delta"][0] == "method"
