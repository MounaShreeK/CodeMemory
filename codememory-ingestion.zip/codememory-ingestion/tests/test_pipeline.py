import pytest
from conftest import SAMPLE_DIR, FakeHindsight

from codememory_ingestion.memory import bank_id_for
from codememory_ingestion.pipeline import ingest_repository
from codememory_ingestion.sources import normalize_repo
from codememory_ingestion.sources.sample import SampleSource

REPO = "sample:payments_demo"


@pytest.fixture()
def ingested():
    memory = FakeHindsight()
    result = ingest_repository(REPO, SampleSource("payments_demo", SAMPLE_DIR), memory, max_commits=50)
    return result, memory


def test_ingest_counts(ingested):
    result, memory = ingested
    assert result.commits_scanned == 6
    assert result.memories_retained == len(result.events) == len(memory.docs) > 0
    assert result.by_type["bug_fix"] >= 3
    assert not result.warnings


def test_idempotency_fix_is_mapped_to_process_payment(ingested):
    result, _ = ingested
    fix = next(e for e in result.events if "double charge" in e["subject"] and e["symbol"].endswith("process_payment"))
    assert fix["symbol"] == "PaymentService.process_payment"
    assert fix["symbol_kind"] == "method"
    assert fix["change_type"] == "bug_fix"
    assert fix["issues"][0]["number"] == 12
    assert "idempotency_key" in fix["diff_snippet"]
    assert any("Redis" in line for line in fix["discussion"])  # PR design decision captured


def test_function_added_in_new_file_is_found(ingested):
    result, _ = ingested
    assert any(e["symbol"] == "to_minor_units" for e in result.events)


def test_retained_text_explains_why(ingested):
    result, memory = ingested
    texts = memory.recall(bank_id_for(REPO), "idempotency double charged", 1)
    assert "idempotency" in texts[0].lower() and "Caution" in texts[0]


def test_retain_receives_timestamp_context_and_stable_document_id(ingested):
    _, memory = ingested
    (bank, doc_id), rec = next(iter(memory.docs.items()))
    assert bank == bank_id_for(REPO) and "::" in doc_id
    assert rec["timestamp"].startswith("2026-") and rec["context"]


def test_reingest_does_not_duplicate():
    memory = FakeHindsight()
    src = SampleSource("payments_demo", SAMPLE_DIR)
    first = ingest_repository(REPO, src, memory)
    count = len(memory.docs)
    ingest_repository(REPO, src, memory)
    assert len(memory.docs) == count == first.memories_retained


@pytest.mark.parametrize("raw,expected", [
    ("https://github.com/owner/name.git", "owner/name"),
    ("owner/name", "owner/name"),
    ("github.com/owner/name/tree/main", "owner/name"),
    ("sample:payments_demo", "sample:payments_demo"),
])
def test_normalize_repo(raw, expected):
    assert normalize_repo(raw) == expected


@pytest.mark.parametrize("bad", ["", "justaname", "bad name/repo", "sample:../etc"])
def test_normalize_repo_rejects_garbage(bad):
    with pytest.raises(ValueError):
        normalize_repo(bad)
