from codememory_ingestion.diff_parser import format_snippet, parse_patch

PATCH = """@@ -5,6 +5,9 @@ class A:
     def f(self):
         x = 1
-        y = 2
+        y = 3
+        z = 4
         return x
+
 tail
\\ No newline at end of file"""


def test_added_and_removed_lines_are_numbered_in_the_new_file():
    lines = parse_patch(PATCH)
    assert [(l.kind, l.new_line, l.text.strip()) for l in lines] == [
        ("-", 7, "y = 2"),
        ("+", 7, "y = 3"),
        ("+", 8, "z = 4"),
        ("+", 10, ""),
    ]


def test_hunk_header_without_counts():
    lines = parse_patch("@@ -1 +1 @@\n-old\n+new")
    assert [(l.kind, l.new_line) for l in lines] == [("-", 1), ("+", 1)]


def test_new_file_patch():
    lines = parse_patch("@@ -0,0 +1,2 @@\n+a\n+b")
    assert [l.new_line for l in lines] == [1, 2]


def test_empty_patch():
    assert parse_patch("") == []
    assert parse_patch(None) == []


def test_snippet_truncates():
    lines = parse_patch("@@ -0,0 +1,50 @@\n" + "\n".join("+line number %d" % i for i in range(50)))
    out = format_snippet(lines, 100)
    assert len(out) <= 120 and out.endswith("(truncated)")
