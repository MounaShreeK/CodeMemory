import pytest

from codememory_ingestion.classifier import classify_change, extract_issue_refs, has_decision_hint


@pytest.mark.parametrize("message,expected", [
    ("fix: prevent double charge (#12)", "bug_fix"),
    ("feat(api): add refunds", "feature"),
    ("refactor: extract helper", "refactor"),
    ("Fixed crash when cart is empty", "bug_fix"),
    ("Add support for JPY", "feature"),
    ("Update README", "docs"),
    ("wip", "other"),
])
def test_classify(message, expected):
    assert classify_change(message) == expected


def test_issue_refs():
    assert extract_issue_refs("fix #12 and #15, also #12 again") == [12, 15]
    assert extract_issue_refs("see org/repo#9") == []
    assert extract_issue_refs("") == []


def test_decision_hint():
    assert has_decision_hint("kept in memory instead of Redis because of cost")
    assert not has_decision_hint("renamed variable")
