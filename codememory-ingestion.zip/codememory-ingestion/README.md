# CodeMemory: ingestion part (GitHub → Tree-sitter → Hindsight)

> GitHub tells us **what** changed, Tree-sitter tells us **where** it changed, Hindsight remembers **why** it matters.

This is one self-contained module. It reads a repository's history, finds the exact function each change
touched, and stores the reasoning in **Hindsight** (the only memory backend). The rest of the team plugs
their frontend / LLM chat on top of it.

```
GitHub API ──► diff parser ──► Tree-sitter ──► change event ──► Hindsight retain
commits, diffs,   changed lines   which function    "process_payment got an
issues, PR text   in the new file  / class they      idempotency check because
                                   belong to         of issue #12"
                                                          │
                          ask a question ◄── recall + reflect ◄┘
```

## Setup

Python 3.10+.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env               # Windows: copy .env.example .env, then add GITHUB_TOKEN
```

Start Hindsight (it needs an LLM key because it extracts facts from what you retain):

```bash
docker run --rm -it -p 8888:8888 -p 9999:9999 \
  -e HINDSIGHT_API_LLM_API_KEY=YOUR_OPENAI_KEY \
  ghcr.io/vectorize-io/hindsight:latest
```

Or use Hindsight Cloud: set `HINDSIGHT_URL` and `HINDSIGHT_API_KEY` in `.env`. See https://hindsight.vectorize.io
if a setting name differs in your version.

## Try it, one step at a time

```bash
python -m pytest -q                                     # 1. tests (don't need Hindsight)
python -m codememory_ingestion check                    # 2. token, Tree-sitter, Hindsight status
python -m codememory_ingestion analyze \
    data/test_data/payment_fix_after.py data/test_data/payment_fix.patch   # 3. Tree-sitter step only
python -m codememory_ingestion ingest sample:payments_demo                 # 4. into Hindsight (offline sample data)
python -m codememory_ingestion ask sample:payments_demo \
    "Why does process_payment check idempotency_key?"                      # 5. recall + reflect
python -m codememory_ingestion ingest owner/name --max-commits 30          # 6. a real repo
```

Step 3 should print `PaymentService.process_payment` as the changed method. You can also open the Hindsight UI
(http://localhost:9999) after step 4 to see the stored memories.

## Use it from code (how your teammates integrate)

```python
from codememory_ingestion import ingest_repository, make_source, bank_id_for
from codememory_ingestion.config import get_settings
from codememory_ingestion.memory import get_memory

s = get_settings()
memory = get_memory(s)

result = ingest_repository("owner/name", make_source("owner/name", s), memory, max_commits=30)
result.memories_retained, result.by_type   # summary
result.events                              # list of dicts, e.g. to save in PostgreSQL

bank = bank_id_for("owner/name")
memory.recall(bank, "Why was this function written this way?")   # list[MemoryHit]
memory.reflect(bank, "What should I be careful about in process_payment?")  # str
```

Their LLM layer can take the `recall` results (or `reflect`'s answer) as context for the final reply.

## What gets stored in Hindsight

One memory per (commit, function). The text is written like a teammate's explanation so Hindsight's fact
extraction works well (see `memory_text.py`):

```
Bug fix in repository owner/name.
Location: method `PaymentService.process_payment` in file `payments/service.py` (lines 9-17).
Commit 4f2c1a9 by Vikram Shah on 2026-02-03: "fix: prevent double charge on retried payments (#12)"
Related issue #12: Customers are double charged when the payment request is retried - ...
Pull request discussion: ... keep processed keys in memory for now instead of Redis ...
What changed (4 lines added, 0 removed):
+ if idempotency_key in self._processed:
+     return self._processed[idempotency_key]
Caution: this change fixed a bug. Before removing or rewriting this logic in `PaymentService.process_payment`, ...
```

Each memory is retained with `context` (type + file + function), `timestamp` (the commit date) and a stable
`document_id` (`<sha>::<file>::<function>`), so re-running ingestion updates instead of duplicating.
One Hindsight memory bank is used per repository (`bank_id_for`).

## Files

| File | Job |
| --- | --- |
| `sources/github.py` | GitHub REST: commits, per-file patches, file text at a commit, issues, PR comments |
| `sources/sample.py` | Offline fixture repo (`sample:payments_demo`) for demos and tests |
| `diff_parser.py` | Unified diff → added/removed lines with their line numbers in the new file |
| `code_analyzer.py` | **Tree-sitter**: list functions/classes; map changed lines to the innermost function |
| `classifier.py` | Commit message → bug_fix / feature / refactor…, `#12` issue references |
| `memory_text.py` | Change event → the text retained in Hindsight |
| `memory.py` | Hindsight client wrapper: retain / recall / reflect |
| `pipeline.py` | `ingest_repository()`: the whole flow |
| `cli.py` | `check`, `ingest`, `ask`, `analyze` commands |

Languages: Python, JavaScript, TypeScript, TSX. To add one, see `LANG_BY_EXT`, `_DEFS` and `_load_parser`
in `code_analyzer.py`. If Tree-sitter isn't installed, Python files fall back to the standard `ast` module
(the analyzer used is stored on every event).

## Limits

- A function that was deleted entirely is attributed to its surrounding scope (old file versions aren't parsed).
- Renames are matched by new path only. Merge commits are skipped (their real commits are indexed).
- Each commit costs several GitHub calls and one Hindsight retain (an LLM call per change). Start with 20-30 commits.
- PR discussion is fetched only when `GITHUB_TOKEN` is set.
