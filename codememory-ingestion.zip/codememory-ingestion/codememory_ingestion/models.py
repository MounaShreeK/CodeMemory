"""Plain dataclasses shared by every layer (no framework imports on purpose)."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Optional


@dataclass
class CommitInfo:
    sha: str
    message: str
    author: str
    date: str  # ISO 8601
    parents: int = 1
    url: str = ""


@dataclass
class FileChange:
    filename: str
    status: str  # added | modified | removed | renamed
    patch: Optional[str] = None
    previous_filename: Optional[str] = None


@dataclass
class IssueInfo:
    number: int
    title: str
    body: str = ""
    comments: list = field(default_factory=list)
    url: str = ""


@dataclass
class DiscussionInfo:
    title: str
    body: str = ""
    comments: list = field(default_factory=list)
    url: str = ""


@dataclass
class Symbol:
    """A function / method / class found by Tree-sitter (1-based inclusive lines)."""

    name: str
    qualified_name: str
    kind: str  # function | method | class | module
    start_line: int
    end_line: int


@dataclass
class DiffLine:
    kind: str  # "+" or "-"
    new_line: int  # "+": its line in the new file. "-": new-file line where the removal happened
    text: str


@dataclass
class SymbolChange:
    symbol: Symbol
    lines: list = field(default_factory=list)

    @property
    def added(self) -> int:
        return sum(1 for l in self.lines if l.kind == "+")

    @property
    def removed(self) -> int:
        return sum(1 for l in self.lines if l.kind == "-")


@dataclass
class ChangeEvent:
    """One 'this function changed in this commit, for this reason' fact."""

    id: str
    repo: str
    sha: str
    short_sha: str
    author: str
    date: str
    subject: str
    message: str
    file: str
    symbol: str
    symbol_kind: str
    start_line: int
    end_line: int
    change_type: str
    added: int
    removed: int
    problem: str
    issues: list
    discussion: list
    diff_snippet: str
    analyzer: str

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class MemoryHit:
    text: str
    type: Optional[str] = None
    score: Optional[float] = None
    context: Optional[str] = None
    date: Optional[str] = None
