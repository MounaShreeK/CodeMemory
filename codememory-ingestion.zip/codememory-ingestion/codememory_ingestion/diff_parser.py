"""Parse GitHub unified-diff patches into line-level changes.

GitHub's commit API returns a `patch` string per file (hunks only, no ---/+++ headers).
We need to know *which lines of the NEW file* were touched so Tree-sitter can tell us
which function those lines live in.
"""
from __future__ import annotations

import re

from .models import DiffLine

HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


def parse_patch(patch: str) -> list:
    """Return every added/removed line with its position in the new file."""
    out: list = []
    new_line = 0
    in_hunk = False
    for raw in (patch or "").splitlines():
        m = HUNK_RE.match(raw)
        if m:
            new_line = int(m.group(3))
            in_hunk = True
            continue
        if not in_hunk or raw.startswith("\\"):  # "\ No newline at end of file"
            continue
        if raw.startswith("+"):
            out.append(DiffLine("+", new_line, raw[1:]))
            new_line += 1
        elif raw.startswith("-"):
            out.append(DiffLine("-", new_line, raw[1:]))
        else:  # context line
            new_line += 1
    return out


def format_snippet(lines: list, max_chars: int = 1200) -> str:
    """Render DiffLines as a compact +/- block, truncated to max_chars."""
    text = "\n".join(f"{l.kind} {l.text}".rstrip() for l in lines)
    if len(text) > max_chars:
        text = text[: max_chars - 15].rstrip() + "\n... (truncated)"
    return text
