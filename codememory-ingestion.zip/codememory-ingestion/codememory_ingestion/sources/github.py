"""GitHub REST API source: 'WHAT changed and WHY' (commits, diffs, issues, PR discussion)."""
from __future__ import annotations

from typing import Optional
from urllib.parse import quote

import httpx

from ..models import CommitInfo, DiscussionInfo, FileChange, IssueInfo
from .base import SourceError

API = "https://api.github.com"


class GitHubSource:
    def __init__(self, repo: str, token: str = "", ref: Optional[str] = None):
        self.repo = repo
        self.ref = ref
        self.has_token = bool(token)
        headers = {
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "CodeMemory",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self.http = httpx.Client(base_url=API, headers=headers, timeout=30.0)

    # ---- low level -----------------------------------------------------------------
    def _get(self, path: str, params=None, accept: Optional[str] = None, soft: bool = False):
        headers = {"Accept": accept} if accept else {}
        try:
            r = self.http.get(path, params=params, headers=headers)
        except httpx.HTTPError as exc:
            raise SourceError(f"Could not reach GitHub: {exc}") from exc
        if r.status_code == 200:
            return r
        if r.status_code in (403, 429) and r.headers.get("x-ratelimit-remaining") == "0":
            raise SourceError(
                "GitHub API rate limit reached. Add a GITHUB_TOKEN to .env (5,000 requests/hour) or retry later."
            )
        if r.status_code == 401:
            raise SourceError("GitHub rejected GITHUB_TOKEN (401). Check that the token is valid.")
        if soft and r.status_code in (403, 404, 410, 422):
            return None
        if r.status_code == 404:
            raise SourceError(f"Repository '{self.repo}' not found, or your token cannot access it.")
        raise SourceError(f"GitHub API error {r.status_code}: {r.text[:200]}")

    # ---- RepoSource interface ------------------------------------------------------
    def list_commits(self, limit: int) -> list:
        commits: list = []
        page = 1
        while len(commits) < limit:
            params = {"per_page": min(100, limit - len(commits)), "page": page}
            if self.ref:
                params["sha"] = self.ref
            rows = self._get(f"/repos/{self.repo}/commits", params=params).json()
            if not rows:
                break
            for c in rows:
                info = c["commit"]
                commits.append(CommitInfo(
                    sha=c["sha"],
                    message=info.get("message", ""),
                    author=(info.get("author") or {}).get("name", "unknown"),
                    date=(info.get("author") or {}).get("date", ""),
                    parents=len(c.get("parents", [])),
                    url=c.get("html_url", ""),
                ))
            page += 1
        return commits[:limit]

    def get_commit_files(self, sha: str) -> list:
        data = self._get(f"/repos/{self.repo}/commits/{sha}").json()
        return [
            FileChange(f["filename"], f["status"], f.get("patch"), f.get("previous_filename"))
            for f in data.get("files", [])
        ]

    def get_file_content(self, path: str, sha: str) -> Optional[str]:
        r = self._get(
            f"/repos/{self.repo}/contents/{quote(path)}",
            params={"ref": sha},
            accept="application/vnd.github.raw+json",
            soft=True,
        )
        return r.text if r is not None else None

    def get_issue(self, number: int) -> Optional[IssueInfo]:
        r = self._get(f"/repos/{self.repo}/issues/{number}", soft=True)
        if r is None:
            return None
        issue = r.json()
        comments: list = []
        if issue.get("comments"):
            cr = self._get(f"/repos/{self.repo}/issues/{number}/comments", params={"per_page": 10}, soft=True)
            if cr is not None:
                comments = [c.get("body", "") for c in cr.json() if c.get("body")]
        return IssueInfo(number, issue.get("title", ""), issue.get("body") or "", comments, issue.get("html_url", ""))

    def get_discussion(self, sha: str) -> Optional[DiscussionInfo]:
        if not self.has_token:  # keeps unauthenticated runs inside the 60 req/hour limit
            return None
        r = self._get(f"/repos/{self.repo}/commits/{sha}/pulls", soft=True)
        prs = r.json() if r is not None else []
        if not prs:
            return None
        pr = prs[0]
        comments: list = []
        for path in (f"/repos/{self.repo}/issues/{pr['number']}/comments",
                     f"/repos/{self.repo}/pulls/{pr['number']}/comments"):
            cr = self._get(path, params={"per_page": 6}, soft=True)
            if cr is not None:
                comments += [c.get("body", "") for c in cr.json() if c.get("body")]
        return DiscussionInfo(pr.get("title", ""), pr.get("body") or "", comments[:8], pr.get("html_url", ""))
