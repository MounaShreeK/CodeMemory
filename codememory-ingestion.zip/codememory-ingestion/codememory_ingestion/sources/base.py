"""The contract every repository source (GitHub, sample fixture, ...) implements."""
from __future__ import annotations

from typing import Optional, Protocol

from ..models import CommitInfo, DiscussionInfo, FileChange, IssueInfo


class SourceError(Exception):
    """Something went wrong reading the repository (bad name, rate limit, bad token...)."""


class RepoSource(Protocol):
    def list_commits(self, limit: int) -> list:
        """Newest first."""

    def get_commit_files(self, sha: str) -> list: ...

    def get_file_content(self, path: str, sha: str) -> Optional[str]:
        """File text as of commit `sha`, or None if unavailable."""

    def get_issue(self, number: int) -> Optional[IssueInfo]: ...

    def get_discussion(self, sha: str) -> Optional[DiscussionInfo]: ...
