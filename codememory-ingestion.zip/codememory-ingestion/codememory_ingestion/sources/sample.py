"""Offline fixture source: lets you demo and test the whole pipeline without GitHub."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional

from ..models import CommitInfo, DiscussionInfo, FileChange, IssueInfo
from .base import SourceError


def list_samples(sample_dir: Path) -> list:
    sample_dir = Path(sample_dir)
    if not sample_dir.exists():
        return []
    return sorted(p.parent.name for p in sample_dir.glob("*/repo.json"))


class SampleSource:
    def __init__(self, name: str, sample_dir: Path):
        path = Path(sample_dir) / name / "repo.json"
        if not path.exists():
            raise SourceError(
                f"Sample repo '{name}' not found at {path}. Available: {', '.join(list_samples(sample_dir)) or 'none'}."
            )
        self.data = json.loads(path.read_text(encoding="utf-8"))
        self._commits = {c["sha"]: c for c in self.data["commits"]}

    def list_commits(self, limit: int) -> list:
        commits = sorted(self.data["commits"], key=lambda c: c["date"], reverse=True)[:limit]
        return [CommitInfo(c["sha"], c["message"], c["author"], c["date"], c.get("parents", 1)) for c in commits]

    def get_commit_files(self, sha: str) -> list:
        c = self._commits[sha]
        return [FileChange(f["filename"], f["status"], f.get("patch")) for f in c["files"]]

    def get_file_content(self, path: str, sha: str) -> Optional[str]:
        for f in self._commits[sha]["files"]:
            if f["filename"] == path:
                return f.get("content_after")
        return None

    def get_issue(self, number: int) -> Optional[IssueInfo]:
        i = self.data.get("issues", {}).get(str(number))
        return IssueInfo(number, i["title"], i.get("body", ""), i.get("comments", [])) if i else None

    def get_discussion(self, sha: str) -> Optional[DiscussionInfo]:
        d = self.data.get("discussions", {}).get(sha)
        return DiscussionInfo(d["title"], d.get("body", ""), d.get("comments", [])) if d else None
