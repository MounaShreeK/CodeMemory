"""Repository sources. `make_source` picks GitHub or an offline sample fixture."""
from __future__ import annotations

import re

from .base import RepoSource, SourceError

__all__ = ["RepoSource", "SourceError", "make_source", "normalize_repo"]

_GITHUB_URL = re.compile(r"^(?:https?://)?(?:www\.)?github\.com/", re.I)
_REPO = re.compile(r"^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")


def normalize_repo(repo: str) -> str:
    """'https://github.com/o/r.git' -> 'o/r'; 'sample:name' stays as is. Raises ValueError."""
    repo = (repo or "").strip()
    if repo.lower().startswith("sample:"):
        name = repo.split(":", 1)[1].strip()
        if not re.fullmatch(r"[A-Za-z0-9_-]+", name):
            raise ValueError("Sample repo names may only contain letters, numbers, - and _.")
        return f"sample:{name}"
    repo = _GITHUB_URL.sub("", repo).rstrip("/")
    if repo.endswith(".git"):
        repo = repo[:-4]
    repo = "/".join(repo.split("/")[:2])
    if not _REPO.match(repo):
        raise ValueError("Repository must look like 'owner/name' (or a github.com URL, or 'sample:payments_demo').")
    return repo


def make_source(repo: str, settings, ref=None) -> RepoSource:
    if repo.startswith("sample:"):
        from .sample import SampleSource

        return SampleSource(repo.split(":", 1)[1], settings.sample_dir)
    from .github import GitHubSource  # imported lazily: needs httpx

    return GitHubSource(repo, settings.github_token, ref)
