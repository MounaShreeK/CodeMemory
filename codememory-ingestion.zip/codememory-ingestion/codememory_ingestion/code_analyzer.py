"""Tree-sitter powered code analysis: 'WHERE did it change?'

extract_symbols()        -> every function / method / class with its line range
map_changes_to_symbols() -> which symbol each changed line belongs to (innermost wins)

If tree-sitter isn't installed, Python files fall back to the stdlib `ast` module so the
rest of the pipeline keeps working. The analyzer used is reported on every event.
"""
from __future__ import annotations

import ast
import functools
import os

from .models import DiffLine, Symbol, SymbolChange

MODULE = "<module>"

LANG_BY_EXT = {
    ".py": "python",
    ".js": "javascript",
    ".jsx": "javascript",
    ".mjs": "javascript",
    ".cjs": "javascript",
    ".ts": "typescript",
    ".tsx": "tsx",
}

# tree-sitter node type -> symbol kind. Add a language here (plus a loader below) to support it.
_JS_DEFS = {
    "function_declaration": "function",
    "generator_function_declaration": "function",
    "class_declaration": "class",
    "method_definition": "method",
}
_DEFS = {
    "python": {"function_definition": "function", "class_definition": "class"},
    "javascript": _JS_DEFS,
    "typescript": {**_JS_DEFS, "abstract_class_declaration": "class"},
    "tsx": {**_JS_DEFS, "abstract_class_declaration": "class"},
}
# `const fn = () => {}` / `const fn = function () {}` are functions too
_FUNC_VALUE_TYPES = {"arrow_function", "function_expression", "function", "generator_function"}


def detect_language(filename: str):
    return LANG_BY_EXT.get(os.path.splitext(filename)[1].lower())


@functools.lru_cache(maxsize=None)
def _load_parser(lang: str):
    """Build a tree-sitter Parser for `lang`, or None if the packages aren't installed."""
    try:
        from tree_sitter import Language, Parser

        if lang == "python":
            import tree_sitter_python as mod

            ptr = mod.language()
        elif lang == "javascript":
            import tree_sitter_javascript as mod

            ptr = mod.language()
        elif lang == "typescript":
            import tree_sitter_typescript as mod

            ptr = mod.language_typescript()
        elif lang == "tsx":
            import tree_sitter_typescript as mod

            ptr = mod.language_tsx()
        else:
            return None
        return Parser(Language(ptr))
    except Exception:
        return None


def extract_symbols(filename: str, source: str, prefer_tree_sitter: bool = True):
    """Return (symbols, analyzer_name)."""
    lang = detect_language(filename)
    if lang is None:
        return [], "unsupported"
    if prefer_tree_sitter:
        parser = _load_parser(lang)
        if parser is not None:
            try:
                return _tree_sitter_symbols(parser, lang, source), "tree-sitter"
            except Exception:
                pass  # fall through to the fallback
    if lang == "python":
        try:
            return _python_ast_symbols(source), "python-ast"
        except SyntaxError:
            return [], "python-ast"
    return [], "none"


def _tree_sitter_symbols(parser, lang: str, source: str) -> list:
    src = source.encode("utf-8")
    tree = parser.parse(src)
    defs = _DEFS[lang]
    out: list = []

    def visit(node, scope, parent_kind):
        kind = defs.get(node.type)
        name_node = None
        if kind:
            name_node = node.child_by_field_name("name")
        elif lang != "python" and node.type == "variable_declarator":
            value = node.child_by_field_name("value")
            if value is not None and value.type in _FUNC_VALUE_TYPES:
                kind = "function"
                name_node = node.child_by_field_name("name")

        child_scope, child_kind = scope, parent_kind
        if kind and name_node is not None:
            name = src[name_node.start_byte : name_node.end_byte].decode("utf-8", "replace")
            if lang == "python" and kind == "function" and parent_kind == "class":
                kind = "method"
            start_row = node.start_point[0]
            parent = node.parent
            if parent is not None and parent.type == "decorated_definition":
                start_row = parent.start_point[0]  # include @decorators in the span
            end_row = node.end_point[0]
            if node.end_point[1] == 0 and end_row > start_row:
                end_row -= 1  # node ends at column 0 of the next line
            out.append(Symbol(name, ".".join(scope + [name]), kind, start_row + 1, end_row + 1))
            child_scope, child_kind = scope + [name], kind

        for child in node.children:
            visit(child, child_scope, child_kind)

    visit(tree.root_node, [], None)
    return out


def _python_ast_symbols(source: str) -> list:
    tree = ast.parse(source)
    out: list = []

    def visit(node, scope, parent_kind):
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                is_class = isinstance(child, ast.ClassDef)
                kind = "class" if is_class else ("method" if parent_kind == "class" else "function")
                start = min([child.lineno] + [d.lineno for d in child.decorator_list])
                end = child.end_lineno or child.lineno
                out.append(Symbol(child.name, ".".join(scope + [child.name]), kind, start, end))
                visit(child, scope + [child.name], kind)
            else:
                visit(child, scope, parent_kind)

    visit(tree, [], None)
    return out


def map_changes_to_symbols(symbols: list, diff_lines: list, module_end: int = 1) -> list:
    """Group changed lines by the innermost symbol that contains them.

    Lines outside any function/class are attributed to a '<module>' pseudo-symbol.
    """

    def innermost(line: int):
        best = None
        for s in symbols:
            if s.start_line <= line <= s.end_line:
                if best is None or (s.end_line - s.start_line) < (best.end_line - best.start_line):
                    best = s
        return best

    module_symbol = Symbol(MODULE, MODULE, "module", 1, max(module_end, 1))
    added_lines = {dl.new_line for dl in diff_lines if dl.kind == "+"}
    groups: dict = {}
    for dl in diff_lines:
        if dl.kind == "+":
            candidates = [dl.new_line]
        elif dl.new_line in added_lines:
            # The removed line was replaced by an added one: it belongs where its replacement is.
            candidates = [dl.new_line, dl.new_line - 1]
        else:
            # A pure removal sits between two surviving lines; prefer the line before it.
            candidates = [dl.new_line - 1, dl.new_line]
        sym = None
        for c in candidates:
            if c >= 1:
                sym = innermost(c)
                if sym:
                    break
        sym = sym or module_symbol
        groups.setdefault(sym.qualified_name, SymbolChange(symbol=sym)).lines.append(dl)
    return list(groups.values())
