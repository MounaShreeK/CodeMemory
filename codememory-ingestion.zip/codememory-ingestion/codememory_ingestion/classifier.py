"""Cheap, explainable heuristics: what kind of change is this commit?"""
from __future__ import annotations

import re

_CONVENTIONAL = re.compile(
    r"^(?P<type>feat|fix|perf|refactor|docs|test|chore|build|ci|style|revert)(\([^)]*\))?!?:", re.I
)
_CONVENTIONAL_MAP = {
    "feat": "feature",
    "fix": "bug_fix",
    "perf": "performance",
    "refactor": "refactor",
    "style": "refactor",
    "docs": "docs",
    "test": "test",
    "chore": "chore",
    "build": "chore",
    "ci": "chore",
    "revert": "revert",
}
_PATTERNS = [
    ("bug_fix", re.compile(r"\b(fix(e[sd])?|bug(fix)?|hotfix|regression|crash(es)?|defect|resolve[sd]?|patch(ed)?)\b", re.I)),
    ("revert", re.compile(r"\brevert", re.I)),
    ("performance", re.compile(r"\b(perf(ormance)?|optimi[sz]e[sd]?|speed ?up|faster)\b", re.I)),
    ("refactor", re.compile(r"\b(refactor(ed)?|clean ?up|tidy|rename[sd]?|restructure[sd]?|extract(ed)?)\b", re.I)),
    ("feature", re.compile(r"\b(add(s|ed)?|implement(s|ed)?|introduce[sd]?|support|new)\b", re.I)),
    ("docs", re.compile(r"\b(docs?|readme|comment(s)?)\b", re.I)),
    ("test", re.compile(r"\b(tests?|coverage)\b", re.I)),
]
_ISSUE_REF = re.compile(r"(?<![\w/])#(\d+)\b")
_DECISION_HINT = re.compile(
    r"\b(because|workaround|instead of|trade-?off|hack|temporary|intentionally|on purpose|must not|do not|don't)\b",
    re.I,
)


def classify_change(message: str) -> str:
    """bug_fix | feature | refactor | performance | revert | docs | test | chore | other"""
    message = message or ""
    subject = message.splitlines()[0] if message else ""
    m = _CONVENTIONAL.match(subject.strip())
    if m:
        return _CONVENTIONAL_MAP[m.group("type").lower()]
    for text in (subject, message):
        for label, pattern in _PATTERNS:
            if pattern.search(text):
                return label
    return "other"


def extract_issue_refs(text: str, limit: int = 3) -> list:
    """Issue/PR numbers mentioned like '#12', in order, de-duplicated."""
    seen: list = []
    for n in _ISSUE_REF.findall(text or ""):
        if int(n) not in seen:
            seen.append(int(n))
    return seen[:limit]


def has_decision_hint(text: str) -> bool:
    return bool(_DECISION_HINT.search(text or ""))
