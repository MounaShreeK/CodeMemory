"""Hindsight memory: retain / recall / reflect.  (Hindsight is the only backend.)

    memory = HindsightMemory(base_url, api_key)
    memory.retain(bank_id, text, context=..., timestamp=..., document_id=...)
    memory.recall(bank_id, query, limit)   -> list[MemoryHit]
    memory.reflect(bank_id, query)         -> str
"""
from __future__ import annotations

import re
import urllib.error
import urllib.request
from typing import Optional

from .models import MemoryHit


class MemoryBackendError(Exception):
    """Hindsight is missing, unreachable, or returned an error."""


def bank_id_for(repo: str) -> str:
    """One Hindsight memory bank per repository."""
    return "codememory-" + re.sub(r"[^a-z0-9]+", "-", repo.lower()).strip("-")


class HindsightMemory:
    name = "hindsight"

    def __init__(self, base_url: str, api_key: Optional[str] = None):
        try:
            from hindsight_client import Hindsight
        except ImportError as exc:
            raise MemoryBackendError(
                "The 'hindsight-client' package is not installed. Run: pip install hindsight-client"
            ) from exc
        kwargs = {"base_url": base_url}
        if api_key:
            kwargs["api_key"] = api_key
        self.base_url = base_url
        self.client = Hindsight(**kwargs)

    def ensure_bank(self, bank_id: str, name: str) -> None:
        # Banks are created on first retain; creating one explicitly is best-effort only.
        try:
            self.client.create_bank(bank_id=bank_id, name=name)
        except Exception:
            pass

    def retain(self, bank_id: str, text: str, *, context: str, timestamp: str, document_id: str) -> None:
        try:
            try:
                self.client.retain(bank_id=bank_id, content=text, context=context,
                                   timestamp=timestamp, document_id=document_id)
            except TypeError:  # older client without document_id
                self.client.retain(bank_id=bank_id, content=text, context=context, timestamp=timestamp)
        except Exception as exc:
            raise MemoryBackendError(f"Hindsight retain failed: {exc}") from exc

    def recall(self, bank_id: str, query: str, limit: int = 8) -> list:
        try:
            result = self.client.recall(bank_id=bank_id, query=query)
        except Exception as exc:
            raise MemoryBackendError(f"Hindsight recall failed: {exc}") from exc
        items = getattr(result, "results", result) or []
        hits = []
        for r in list(items)[:limit]:
            hits.append(MemoryHit(
                text=getattr(r, "text", str(r)),
                type=getattr(r, "type", None),
                score=getattr(r, "score", None),
                context=getattr(r, "context", None),
                date=str(getattr(r, "occurred_start", None) or getattr(r, "date", None) or "") or None,
            ))
        return hits

    def reflect(self, bank_id: str, query: str) -> str:
        try:
            answer = self.client.reflect(bank_id=bank_id, query=query)
        except Exception as exc:
            raise MemoryBackendError(f"Hindsight reflect failed: {exc}") from exc
        return getattr(answer, "text", None) or str(answer)

    def health(self) -> dict:
        """Best-effort reachability check (any HTTP answer counts as reachable)."""
        try:
            urllib.request.urlopen(f"{self.base_url}/health", timeout=3)
            return {"reachable": True, "url": self.base_url}
        except urllib.error.HTTPError:
            return {"reachable": True, "url": self.base_url}
        except Exception as exc:
            return {"reachable": False, "url": self.base_url, "error": str(exc)}


def get_memory(settings) -> HindsightMemory:
    return HindsightMemory(settings.hindsight_url, settings.hindsight_api_key or None)
