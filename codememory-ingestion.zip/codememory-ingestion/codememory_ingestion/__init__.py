"""CodeMemory ingestion: GitHub history -> Tree-sitter symbols -> Hindsight memory."""
from .memory import HindsightMemory, MemoryBackendError, bank_id_for
from .pipeline import IngestResult, ingest_repository
from .sources import SourceError, make_source, normalize_repo

__all__ = [
    "HindsightMemory",
    "MemoryBackendError",
    "bank_id_for",
    "IngestResult",
    "ingest_repository",
    "SourceError",
    "make_source",
    "normalize_repo",
]
