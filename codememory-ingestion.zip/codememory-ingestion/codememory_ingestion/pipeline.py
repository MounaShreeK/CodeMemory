"""The ingestion pipeline:  GitHub (what/why)  ->  Tree-sitter (where)  ->  Hindsight (remember).

Entry point for the rest of the team:

    result = ingest_repository(repo, source, memory, max_commits=30)
    result.events  # every change as a plain dict, if you also want to save it in PostgreSQL
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable, Optional

from .classifier import classify_change, extract_issue_refs
from .code_analyzer import detect_language, extract_symbols, map_changes_to_symbols
from .diff_parser import format_snippet, parse_patch
from .memory import bank_id_for
from .memory_text import build_memory_text
from .models import ChangeEvent
from .sources.base import SourceError

_SKIP_PATH = re.compile(r"(^|/)(node_modules|dist|build|vendor|__pycache__|\.venv|venv)/|\.min\.js$")


@dataclass
class IngestResult:
    repo: str
    bank_id: str
    commits_scanned: int = 0
    commits_skipped: int = 0
    memories_retained: int = 0
    by_type: dict = field(default_factory=dict)
    analyzers: dict = field(default_factory=dict)
    warnings: list = field(default_factory=list)
    events: list = field(default_factory=list)  # list[dict], see ChangeEvent


def ingest_repository(
    repo: str,
    source,
    memory,
    *,
    max_commits: int = 30,
    max_diff_chars: int = 1200,
    max_events_per_commit: int = 12,
    progress: Optional[Callable[[int, int, str], None]] = None,
) -> IngestResult:
    bank_id = bank_id_for(repo)
    result = IngestResult(repo=repo, bank_id=bank_id)
    memory.ensure_bank(bank_id, repo)

    commits = list(reversed(source.list_commits(max_commits)))  # oldest first
    issue_cache: dict = {}

    for i, commit in enumerate(commits):
        if progress:
            first_line = commit.message.splitlines()[0][:60] if commit.message else ""
            progress(i, len(commits), f"{commit.sha[:7]} {first_line}")
        if commit.parents > 1:  # merge commits only duplicate the real commits
            result.commits_skipped += 1
            continue
        try:
            built = _events_for_commit(repo, source, commit, issue_cache, max_diff_chars, max_events_per_commit)
        except SourceError as exc:
            result.warnings.append(f"{commit.sha[:7]}: {exc}")
            continue

        result.commits_scanned += 1
        for event in built:
            memory.retain(  # raises MemoryBackendError if Hindsight is down
                bank_id,
                build_memory_text(event),
                context=f"{event.change_type} in {event.file} :: {event.symbol}",
                timestamp=event.date,
                document_id=event.id,  # same id on re-run => updated, not duplicated
            )
            result.memories_retained += 1
            result.by_type[event.change_type] = result.by_type.get(event.change_type, 0) + 1
            result.analyzers[event.analyzer] = result.analyzers.get(event.analyzer, 0) + 1
            result.events.append(event.to_dict())

    if progress:
        progress(len(commits), len(commits), "done")
    return result


def _events_for_commit(repo, source, commit, issue_cache, max_diff_chars, max_events) -> list:
    subject = commit.message.splitlines()[0] if commit.message else ""
    change_type = classify_change(commit.message)

    issues = []
    for number in extract_issue_refs(commit.message):
        if number not in issue_cache:
            issue_cache[number] = source.get_issue(number)
        if issue_cache[number]:
            issues.append(issue_cache[number])

    discussion = source.get_discussion(commit.sha)
    discussion_lines = []
    if discussion:
        if discussion.body:
            discussion_lines.append(f"{discussion.title}: {discussion.body}")
        discussion_lines += discussion.comments

    problem = issues[0].title if issues else subject
    issue_dicts = [{"number": i.number, "title": i.title, "body": i.body, "comments": i.comments} for i in issues]

    events: list = []
    for f in source.get_commit_files(commit.sha):
        if f.status == "removed" or not f.patch or _SKIP_PATH.search(f.filename):
            continue
        if detect_language(f.filename) is None:
            continue
        content = source.get_file_content(f.filename, commit.sha)
        if content is not None:
            symbols, analyzer = extract_symbols(f.filename, content)
        else:
            symbols, analyzer = [], "no-content"
        module_end = content.count("\n") + 1 if content else 1
        for change in map_changes_to_symbols(symbols, parse_patch(f.patch), module_end):
            sym = change.symbol
            events.append(ChangeEvent(
                id=f"{commit.sha[:10]}::{f.filename}::{sym.qualified_name}",
                repo=repo,
                sha=commit.sha,
                short_sha=commit.sha[:7],
                author=commit.author,
                date=commit.date,
                subject=subject,
                message=commit.message,
                file=f.filename,
                symbol=sym.qualified_name,
                symbol_kind=sym.kind,
                start_line=sym.start_line,
                end_line=sym.end_line,
                change_type=change_type,
                added=change.added,
                removed=change.removed,
                problem=problem,
                issues=issue_dicts,
                discussion=discussion_lines,
                diff_snippet=format_snippet(change.lines, max_diff_chars),
                analyzer=analyzer,
            ))
    events.sort(key=lambda e: e.added + e.removed, reverse=True)
    return events[:max_events]
