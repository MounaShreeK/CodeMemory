"""Turn a ChangeEvent into the natural-language record we retain in Hindsight.

Hindsight extracts facts from prose with an LLM, so we write the record the way a
teammate would explain the change: what, where, why, and what to be careful about.
"""
from __future__ import annotations

from .classifier import has_decision_hint
from .models import ChangeEvent

TYPE_LABEL = {
    "bug_fix": "Bug fix",
    "feature": "Feature",
    "refactor": "Refactor",
    "performance": "Performance change",
    "revert": "Revert",
    "docs": "Documentation change",
    "test": "Test change",
    "chore": "Maintenance change",
    "other": "Code change",
}


def _clip(text: str, limit: int) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= limit else text[: limit - 3].rstrip() + "..."


def build_memory_text(e: ChangeEvent) -> str:
    label = TYPE_LABEL.get(e.change_type, "Code change")
    where = f"`{e.symbol}`" if e.symbol != "<module>" else "module-level code"
    kind = f"{e.symbol_kind} " if e.symbol != "<module>" else ""

    parts = [
        f"{label} in repository {e.repo}.",
        f"Location: {kind}{where} in file `{e.file}` (lines {e.start_line}-{e.end_line}).",
        f'Commit {e.short_sha} by {e.author} on {e.date[:10]}: "{e.subject}"',
    ]

    if e.problem and e.problem != e.subject:
        parts.append(f"Problem / reason: {_clip(e.problem, 300)}")
    for issue in e.issues:
        line = f"Related issue #{issue['number']}: {_clip(issue['title'], 160)}"
        if issue.get("body"):
            line += f" - {_clip(issue['body'], 350)}"
        parts.append(line)
        for c in issue.get("comments", [])[:3]:
            parts.append(f"  Issue discussion: {_clip(c, 300)}")
    for c in e.discussion[:4]:
        parts.append(f"Pull request discussion: {_clip(c, 300)}")

    body = e.message.split("\n", 1)[1].strip() if "\n" in e.message else ""
    if body:
        parts.append(f"Commit details: {_clip(body, 500)}")

    parts.append(f"What changed ({e.added} lines added, {e.removed} removed):\n{e.diff_snippet}")

    if e.change_type == "bug_fix":
        parts.append(
            f"Caution: this change fixed a bug. Before removing or rewriting this logic in {where}, "
            "review the problem above so the bug is not reintroduced."
        )
    elif has_decision_hint(e.message + " " + " ".join(e.discussion)):
        parts.append("Note: the commit or discussion records a deliberate design decision; check it before changing this code.")

    return "\n".join(parts)
