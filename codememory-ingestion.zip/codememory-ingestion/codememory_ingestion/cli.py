"""Command line for your part.

    python -m codememory_ingestion check
    python -m codememory_ingestion ingest sample:payments_demo
    python -m codememory_ingestion ingest owner/name --max-commits 30
    python -m codememory_ingestion ask sample:payments_demo "Why does process_payment check idempotency_key?"
    python -m codememory_ingestion analyze data/test_data/payment_fix_after.py data/test_data/payment_fix.patch
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .code_analyzer import _load_parser, detect_language, extract_symbols, map_changes_to_symbols
from .config import get_settings
from .diff_parser import parse_patch
from .memory import MemoryBackendError, bank_id_for, get_memory
from .pipeline import ingest_repository
from .sources import SourceError, make_source, normalize_repo


def _check(_args) -> int:
    s = get_settings()
    ok = True
    print(f"GitHub token : {'set' if s.github_token else 'NOT set (60 requests/hour limit)'}")
    for lang in ("python", "javascript", "typescript"):
        print(f"Tree-sitter {lang:<10}: {'ok' if _load_parser(lang) else 'not installed (Python falls back to ast)'}")
    try:
        health = get_memory(s).health()
        print(f"Hindsight    : {'reachable' if health['reachable'] else 'UNREACHABLE'} at {health['url']}")
        ok = health["reachable"]
    except MemoryBackendError as exc:
        print(f"Hindsight    : {exc}")
        ok = False
    return 0 if ok else 1


def _ingest(args) -> int:
    s = get_settings()
    repo = normalize_repo(args.repo)
    memory = get_memory(s)
    result = ingest_repository(
        repo, make_source(repo, s, args.ref), memory,
        max_commits=args.max_commits,
        max_diff_chars=s.max_diff_chars,
        max_events_per_commit=s.max_events_per_commit,
        progress=lambda done, total, msg: print(f"[{done}/{total}] {msg}", file=sys.stderr),
    )
    summary = {k: v for k, v in result.__dict__.items() if k != "events"}
    print(json.dumps(summary, indent=2))
    if args.dump_events:
        Path(args.dump_events).write_text(json.dumps(result.events, indent=2), encoding="utf-8")
        print(f"events written to {args.dump_events}", file=sys.stderr)
    return 0


def _ask(args) -> int:
    s = get_settings()
    repo = normalize_repo(args.repo)
    memory = get_memory(s)
    bank = bank_id_for(repo)
    if not args.no_reflect:
        print("ANSWER\n" + memory.reflect(bank, args.question) + "\n")
    hits = memory.recall(bank, args.question, args.limit)
    print(f"RECALLED MEMORIES ({len(hits)})")
    for h in hits:
        print("-", h.text.splitlines()[0] if h.text else "")
    return 0


def _analyze(args) -> int:
    """Run only the Tree-sitter step: which functions does this patch touch?"""
    content = Path(args.file).read_text(encoding="utf-8")
    patch = Path(args.patch).read_text(encoding="utf-8")
    if detect_language(args.file) is None:
        print("Unsupported file type.")
        return 1
    symbols, analyzer = extract_symbols(args.file, content)
    print(f"analyzer: {analyzer}")
    for c in map_changes_to_symbols(symbols, parse_patch(patch), content.count("\n") + 1):
        print(f"- {c.symbol.qualified_name} [{c.symbol.kind}] lines {c.symbol.start_line}-{c.symbol.end_line}: "
              f"+{c.added} -{c.removed}")
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="codememory_ingestion", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("check", help="verify token, Tree-sitter and Hindsight").set_defaults(fn=_check)

    i = sub.add_parser("ingest", help="read a repo's history into Hindsight")
    i.add_argument("repo", help="owner/name, a github.com URL, or sample:payments_demo")
    i.add_argument("--max-commits", type=int, default=30)
    i.add_argument("--ref", help="branch or tag")
    i.add_argument("--dump-events", metavar="FILE", help="also save the structured events as JSON")
    i.set_defaults(fn=_ingest)

    a = sub.add_parser("ask", help="recall + reflect over what was remembered")
    a.add_argument("repo")
    a.add_argument("question")
    a.add_argument("--limit", type=int, default=8)
    a.add_argument("--no-reflect", action="store_true")
    a.set_defaults(fn=_ask)

    n = sub.add_parser("analyze", help="test Tree-sitter mapping on a local file + patch")
    n.add_argument("file")
    n.add_argument("patch")
    n.set_defaults(fn=_analyze)

    args = p.parse_args(argv)
    try:
        return args.fn(args)
    except (SourceError, MemoryBackendError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
