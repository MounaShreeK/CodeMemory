"""Settings, read from environment variables (and an optional .env file in the project root)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # python-dotenv is optional
    load_dotenv = None

PROJECT_DIR = Path(__file__).resolve().parents[1]

if load_dotenv:
    load_dotenv(PROJECT_DIR / ".env")


@dataclass(frozen=True)
class Settings:
    github_token: str
    hindsight_url: str
    hindsight_api_key: str
    data_dir: Path
    max_diff_chars: int
    max_events_per_commit: int

    @property
    def sample_dir(self) -> Path:
        return self.data_dir / "sample_repositories"


def get_settings() -> Settings:
    return Settings(
        github_token=os.getenv("GITHUB_TOKEN", "").strip(),
        hindsight_url=os.getenv("HINDSIGHT_URL", "http://localhost:8888").rstrip("/"),
        hindsight_api_key=os.getenv("HINDSIGHT_API_KEY", "").strip(),
        data_dir=Path(os.getenv("DATA_DIR", str(PROJECT_DIR / "data"))),
        max_diff_chars=int(os.getenv("MAX_DIFF_CHARS", "1200")),
        max_events_per_commit=int(os.getenv("MAX_EVENTS_PER_COMMIT", "12")),
    )
