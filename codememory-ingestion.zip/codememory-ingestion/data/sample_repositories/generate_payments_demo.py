"""Regenerates payments_demo/repo.json: a small fake repo history for offline demos.

Patches are produced with difflib from real file versions, so line numbers always match
the file contents (which is what the Tree-sitter mapping step needs).

    python data/sample_repositories/generate_payments_demo.py
"""
import difflib
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).parent / "payments_demo" / "repo.json"

SERVICE_V1 = '''"""Payment processing service."""
from payments.gateway import Gateway


class PaymentService:
    def __init__(self, gateway: Gateway):
        self.gateway = gateway

    def process_payment(self, user_id, amount, currency="USD"):
        charge = self.gateway.charge(user_id, amount, currency)
        return {"status": "ok", "charge_id": charge["id"]}
'''

SERVICE_V2 = SERVICE_V1 + '''
    def refund_payment(self, charge_id, amount):
        refund = self.gateway.refund(charge_id, amount)
        return {"status": "refunded", "refund_id": refund["id"]}
'''

SERVICE_V3 = '''"""Payment processing service."""
from payments.gateway import Gateway


class PaymentService:
    def __init__(self, gateway: Gateway):
        self.gateway = gateway
        self._processed = {}

    def process_payment(self, user_id, amount, currency="USD", idempotency_key=None):
        if idempotency_key in self._processed:
            return self._processed[idempotency_key]
        charge = self.gateway.charge(user_id, amount, currency)
        result = {"status": "ok", "charge_id": charge["id"]}
        if idempotency_key:
            self._processed[idempotency_key] = result
        return result

    def refund_payment(self, charge_id, amount):
        refund = self.gateway.refund(charge_id, amount)
        return {"status": "refunded", "refund_id": refund["id"]}
'''

SERVICE_V4 = SERVICE_V3.replace(
    '''        if idempotency_key in self._processed:''',
    '''        if amount <= 0:
            raise ValueError("amount must be positive")
        if idempotency_key in self._processed:''',
)

CURRENCY_V5 = '''"""Currency helpers."""

ZERO_DECIMAL_CURRENCIES = {"JPY", "KRW", "VND"}


def to_minor_units(amount, currency):
    if currency.upper() in ZERO_DECIMAL_CURRENCIES:
        return int(round(amount))
    return int(round(amount * 100))
'''

SERVICE_V5 = SERVICE_V4.replace(
    "from payments.gateway import Gateway\n",
    "from payments.currency import to_minor_units\nfrom payments.gateway import Gateway\n",
).replace(
    "charge = self.gateway.charge(user_id, amount, currency)",
    "charge = self.gateway.charge(user_id, to_minor_units(amount, currency), currency)",
)

SERVICE_V6 = SERVICE_V5.replace(
    '''        if amount <= 0:
            raise ValueError("amount must be positive")
''',
    '''        self._validate_amount(amount)
''',
) + '''
    def _validate_amount(self, amount):
        if amount <= 0:
            raise ValueError("amount must be positive")
'''

S, C = "payments/service.py", "payments/currency.py"
HISTORY = [
    ("feat: add PaymentService with process_payment", "Asha Rao", "2026-01-05T09:30:00Z", {S: SERVICE_V1}),
    ("feat: add refund_payment to PaymentService", "Asha Rao", "2026-01-19T11:05:00Z", {S: SERVICE_V2}),
    ("fix: prevent double charge on retried payments (#12)\n\n"
     "Mobile clients retry POST /pay after a timeout. Accept an idempotency key and return the "
     "stored result for repeated keys instead of charging again.",
     "Vikram Shah", "2026-02-03T14:20:00Z", {S: SERVICE_V3}),
    ("fix: reject zero and negative amounts (#15)", "Meera Iyer", "2026-02-17T10:45:00Z", {S: SERVICE_V4}),
    ("fix: charge JPY correctly, it has no minor units (#18)\n\n"
     "We multiplied every amount by 100, so JPY customers were charged 100x. Add to_minor_units().",
     "Vikram Shah", "2026-03-02T16:10:00Z", {S: SERVICE_V5, C: CURRENCY_V5}),
    ("refactor: extract _validate_amount from process_payment", "Meera Iyer", "2026-03-16T12:00:00Z", {S: SERVICE_V6}),
]

ISSUES = {
    "12": {
        "title": "Customers are double charged when the payment request is retried",
        "body": "Mobile clients retry POST /pay when the gateway times out. The gateway had already charged "
                "the card, so the retry created a second charge.",
        "comments": [
            "Reproduced: the gateway timed out after charging; the retry created a second charge.",
            "Plan: accept an idempotency key from the client and return the stored result for repeated keys.",
        ],
    },
    "15": {
        "title": "Zero or negative amount creates an invalid charge",
        "body": "A client bug sent amount=-5 and the gateway recorded a credit instead of rejecting it.",
        "comments": ["Validate the amount before touching the gateway."],
    },
    "18": {
        "title": "JPY payments are charged 100x too much",
        "body": "JPY has no minor units. Multiplying by 100 like USD made a 500 yen payment cost 50,000 yen.",
        "comments": ["Zero-decimal currencies (JPY, KRW, VND) must not be multiplied by 100."],
    },
}


def make_patch(old: str, new: str) -> str:
    diff = list(difflib.unified_diff(old.splitlines(), new.splitlines(), lineterm="", n=3))
    return "\n".join(diff[2:])  # drop the ---/+++ headers, like GitHub does


def main() -> None:
    state: dict = {}
    commits = []
    for i, (message, author, date, files) in enumerate(HISTORY):
        sha = hashlib.sha1(f"{i}:{message}".encode()).hexdigest()
        changed = []
        for filename, content in files.items():
            before = state.get(filename)
            changed.append({
                "filename": filename,
                "status": "modified" if before is not None else "added",
                "patch": make_patch(before or "", content),
                "content_after": content,
            })
            state[filename] = content
        commits.append({"sha": sha, "message": message, "author": author, "date": date, "parents": 1, "files": changed})

    fix12 = commits[2]["sha"]
    data = {
        "repo": "sample:payments_demo",
        "commits": commits,
        "issues": ISSUES,
        "discussions": {
            fix12: {
                "title": "Idempotency keys for /pay",
                "body": "Decision: keep processed keys in memory for now instead of Redis, because the "
                        "gateway already de-duplicates within 24 hours.",
                "comments": ["Reviewer: should we persist keys? Author: not yet, in-memory covers the retry window."],
            }
        },
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data, indent=1), encoding="utf-8")
    print(f"wrote {OUT} ({len(commits)} commits)")


if __name__ == "__main__":
    main()
