# test_data

Small hand-made inputs for trying the analyzer without a full repository.

`payment_fix.patch` is the diff of the "prevent double charge" fix (issue #12). Paste it, together
with the file contents after the change, into `POST /api/analyze` to see which functions it touches:

```bash
curl -s localhost:8000/api/analyze -H 'content-type: application/json' -d '{
  "filename": "payments/service.py",
  "content": "<file text after the change>",
  "patch": "<contents of payment_fix.patch>"
}'
```
