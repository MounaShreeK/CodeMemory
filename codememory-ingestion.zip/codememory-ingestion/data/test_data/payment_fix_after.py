"""Payment processing service."""
from payments.gateway import Gateway


class PaymentService:
    def __init__(self, gateway: Gateway):
        self.gateway = gateway
        self._processed = {}

    def process_payment(self, user_id, amount, currency="USD", idempotency_key=None):
        if idempotency_key in self._processed:
            return self._processed[idempotency_key]
        charge = self.gateway.charge(user_id, amount, currency)
        result = {"status": "ok", "charge_id": charge["id"]}
        if idempotency_key:
            self._processed[idempotency_key] = result
        return result

    def refund_payment(self, charge_id, amount):
        refund = self.gateway.refund(charge_id, amount)
        return {"status": "refunded", "refund_id": refund["id"]}
